// import { createStore, applyMiddleware } from 'redux';
// import thunkMiddleware from 'redux-thunk';
// import { createLogger } from 'redux-logger';
// import authentication from './reducers/rd_login2';
// const loggerMiddleware = createLogger();
// const store = createStore(authentication, applyMiddleware(
//     thunkMiddleware,
//     loggerMiddleware
// ));
// export default store;