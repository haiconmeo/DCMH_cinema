import React from 'react';

class Giave extends React.Component {
    render(){
        return(
            <div style={{textAlign:"center"}} className="gia-ve">
                
                <img src="/img/giave.jpg"/>
            </div>
        );
    }
}
export default Giave;