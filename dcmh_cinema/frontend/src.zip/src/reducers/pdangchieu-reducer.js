export default() => {
    return [
            {id:1,
            img : "../images/phim3.jpg",
            name : "MALEFICENT 2", date: "18/10/2019",
            time: "120Phút",
            video: "http://www.lottecinemavn.com/Media/MovieFile/MovieMedia/201905/10194_301_100001.mp4",
            poster :"../images/poster1.jpg",
            tt :"Thời gian trôi qua thật bình yên với Maleficent và Aurora. Mặc dù mối quan hệ của cả hai được tạo dựng từ những tổn thương, thù hận rồi sau đó mới đến tình yêu thương nhưng cuối cùng thì nó cũng đã đơm hoa kết trái. Tuy vậy, xung đột giữa hai giới: loài người và tiên tộc vẫn vẫn luôn hiện hữu. Cuộc hôn nhân vốn bị trì hoãn giữa Aurora và Hoàng tử Phillips chính là cầu nối gắn kết Vương quốc Ulstead và nước láng giềng Moors lại với nhau. Bất ngờ thay, sự xuất hiện của một phe đồng minh hoàn toàn mới sẽ khiến Maleficent và Aurora bị chia cắt về hai chiến tuyến trong trận Đại Chiến. Trận chiến này sẽ thử thách lòng tin lẫn tình cảm của cả hai. Liệu rằng họ có thật sự trở thành một gia đình hay không? Tất cả sẽ được giải đáp trong Maleficent: Mistress of Evil/ Tiên Hắc Ám 2."},

            {id:2,
            img : "../images/phim2.jpg",
            name : "VÙNG ĐẤT THÂY MA", 
            date: "25/10/2019", time: "115Phút", 
            video: "http://www.lottecinemavn.com/Media/MovieFile/MovieMedia/201909/10303_301_100001.mp4", 
            poster :"../images/poster2.jpg",
            tt :"Sau 10 năm dài đẵng đằng, Zombieland 2 đã chính thức trở lại với mốc thời gian 10 năm tương tự ngoài thực tế. Double Tap tiếp tục xoay quanh nhóm nhân vật chính lầy lội gồm: Columbus (Jesse Eisenberg) - thanh niên mọt sách nhút nhát luôn trung thành theo bộ nguyên tắc sinh tồn do cậu đề ra, gã “Sát thủ Zombie” Tallahassee (Woody Harrelson) cao ngạo bị nghiện món bánh Twinkie cùng hai chị em lừa lọc Wichita (Emma Stone) - Little Rock (Abigail Breslin). Nhằm tìm kiếm các tập thể người vẫn còn sống sót, bọn họ đã quyết định “đi phượt” tới trung tâm hành chính của bờ đông Hoa Kì, tức thủ đô Washington D.C và quét sạch hết thảy mọi thể loại thây ma dám cả gan ngáng đường..."},
            
            {id:3,
            img : "../images/phim1.jpg",
            name : "JOKER", 
            date: "04/10/2019",
            time: "120Phút",
            video: "http://www.lottecinemavn.com/Media/MovieFile/MovieMedia/201909/10290_301_100001.mp4", 
            poster :"../images/poster3.jpg",
            tt : "Phim lấy bối cảnh những năm 1980, lúc này, kẻ thù của Batman vẫn còn là một diễn viên hài thảm hại mang tên Arthur Fleck. Sau nhiều biến cố lớn, Arthur dần lún sâu hơn và những trò bệnh hoạn của mình và trở thành một kẻ cuồng sát."},
            
            {id:4, 
            img : "../images/phim5.jpg", 
            name : "ĐÀN ÔNG SONG TỬ", 
            date: "11/10/2019",
            time: "120Phút",
            video: "http://www.lottecinemavn.com/Media/MovieFile/MovieMedia/201909/10290_301_100001.mp4", 
            poster :"../images/poster3.jpg",},
            
            {id:5,
            img : "../images/phim4.jpg",
            name : "THẤT SƠN TÂM LINH",
            date: "09/10/2019",
            time: "105Phút",
            video: "http://www.lottecinemavn.com/Media/MovieFile/MovieMedia/201909/10290_301_100001.mp4", 
            poster :"../images/poster3.jpg",},
        ]
}