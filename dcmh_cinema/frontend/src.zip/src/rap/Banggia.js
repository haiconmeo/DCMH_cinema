import React from 'react';
// import './Banggia.css'
class Banggia extends React.Component{
    constructor(props){
      super(props)
    }
    render(){
      return(
        <div>
            <img src="./img/banggia.jpg"  alt=""/>
        </div>
      );
    };
  }
export  default Banggia;