import React from 'react';
// import './App.css';
class Huongdan extends React.Component {
    constructor(props) {
        super(props)
        this.state={
            huongdan: ["Galaxy Kinh Dương Vương là cụm rạp chiếu phim đầu tiên và duy nhất tại khu vực quận 6 tính cho đến năm 2016.   Ngay từ lúc khai trương vào năm 2013, nơi đây đã có 7 phòng chiếu được thiết kế theo tiêu chuẩn quốc tế với khoảng cách ghế ngồi rộng rãi. Bên cạnh đó, hệ thống âm thanh Dolby 7.1, màn hình chiếu kỹ thuật 3D và Digital vô cùng mịn, sắc nét đến từng phút giây mang đến những trải nghiệm phim hay cực đỉnh.   Sự ra đời của Galaxy Kinh Dương Vương thỏa khao khát từ lâu của các tín đồ điện ảnh. Chỉ mới đây thôi, cư dân Q.6 và các vùng lân cận muốn thưởng thức một bộ phim mới tại rạp bắt buộc phải lặn lội vào trung tâm. Đặc biệt, chỉ qua 3 ngày đầu tiên khai trương, rạp đã đạt mức vé bán kỷ lục là hơn 16.000 vé."

            
        ]
        }
    }
    render() {
        return (
            <div>
                <ul>
                <textarea >
                </textarea >
                    
                </ul>
            </div>
        );
    };
}
export default Huongdan;