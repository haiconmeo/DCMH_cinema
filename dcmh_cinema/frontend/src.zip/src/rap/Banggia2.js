import React from 'react';
// import './Banggia.css'
class Banggia2 extends React.Component{
    constructor(props){
      super(props)
    }
    render(){
      return(
        <div>
            <img src="./img/map.jpg"  alt=""/>
        </div>
      );
    };
  }
export  default Banggia2;