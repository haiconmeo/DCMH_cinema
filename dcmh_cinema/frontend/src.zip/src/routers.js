import React from 'react';
import Home from './App'

const routes = [{
        path: '/',
        exact: true,
        main: () => < Home / >
    },
    {

    }
]
export default routes;