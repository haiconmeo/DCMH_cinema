

export const AddSeat = (seats) => {
    return {
        type: "ADD_SEAT",
        seats
    }
}