export const tongtien = (tien) => ({
    type: 'SHOW_TONGTIEN',
    data: tien
});