

export const status = (seats) => {
    return {
        type: "STATUS",
        seats
    }
}